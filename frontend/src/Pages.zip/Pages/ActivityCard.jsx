// Viser aktivitet og håndterer billettvalg og handlekurv
import { ActivityParticipants, TicketPurchase } from "./ActivityTickets.jsx";
import { useState } from "react";
import { useCart } from "./cartContext.js";
import "./ContentStatus.css";
import {
  activityPriceFormatter,
  activityStatusOptions,
  fallbackActivityColors,
  formatActivityDate,
  formatActivityDuration,
  getActivityImageSource,
  getActivityPriceRange,
  getDiscountAmountText,
  getDiscountPeriodText,
  getMemberTypeLabel,
  isDiscountExpired,
  knownActivityDecorations,
} from "./activityUtils.js";

export function ActivityCard({ activityData, activityIndex = 0, ticketSales }) {
  const { add, error } = useCart();
  const [added, setAdded] = useState(false);
  const decoration = knownActivityDecorations[activityData.id] || {
    emoji: "✣",
    color: fallbackActivityColors[activityIndex % fallbackActivityColors.length],
    tagline: activityData.category || "Aktivitet",
  };
  const priceRange = getActivityPriceRange(activityData.ticketTypes);
  const discount = activityData.discount && !isDiscountExpired(activityData.discount) ? activityData.discount : null;
  return (
    <article className="activity-card">
      <header className={`activity-image activity-image-${decoration.color}`}>
        {activityData.imageUrl
          ? <img className="activity-card-photo" src={getActivityImageSource(activityData.imageUrl)} alt="" />
          : <span aria-hidden="true">{decoration.emoji}</span>}
        <small>{decoration.tagline}</small>
      </header>
      <section className="activity-content">
        <p className="activity-category">{activityData.category || "Aktivitet"}</p>
        {activityData.status && activityData.status !== "published" && (
          <p className="content-status">{activityStatusOptions.find(([status]) => status === activityData.status)?.[1]}</p>
        )}
        <h3>{activityData.title}</h3>
        <details className="activity-details">
          <summary>Les mer om aktiviteten</summary>
          {activityData.description
            // Beskrivelsen er allerede sanitert av API-et; vanlig tekst rendres fortsatt som tekst
            ? activityData.description.includes("<")
              ? <div className="activity-description" dangerouslySetInnerHTML={{ __html: activityData.description }} />
              : <p className="activity-description">{activityData.description}</p>
            : <p className="activity-description">Ingen nærmere beskrivelse er lagt til.</p>}
        </details>
        {discount && (
          <p className="activity-discount">
            <strong>Rabatt: {getDiscountAmountText(discount)}</strong>
            {" "}for {discount.memberTypes.map(getMemberTypeLabel).join(", ").toLowerCase()}
            {getDiscountPeriodText(discount) && <> ({getDiscountPeriodText(discount)})</>}
          </p>
        )}
        <dl>
          <section>
            <dt>Dato</dt>
            <dd>{formatActivityDate(activityData.date)}</dd>
          </section>
          <section>
            <dt>Tid</dt>
            <dd>{activityData.time}</dd>
          </section>
          <section>
            <dt>Sted</dt>
            <dd>{activityData.location}</dd>
          </section>
          <section>
            <dt>Pris</dt>
            <dd>{priceRange || "Ikke oppgitt"}</dd>
          </section>
          {activityData.durationMinutes && (
            <section>
              <dt>Varighet</dt>
              <dd>{formatActivityDuration(activityData.durationMinutes)}</dd>
            </section>
          )}
        </dl>
        {activityData.ticketTypes?.length > 0 && (
          <section className="activity-ticket-list" aria-label="Billettyper">
            <h4>Billetter</h4>
            {activityData.ticketTypes.map((ticketType) => (
              <article key={ticketType.name}>
                <strong>
                  {ticketType.name} · {activityPriceFormatter.format(ticketType.price)}
                </strong>
                {ticketType.description && <p>{ticketType.description}</p>}
                <small>
                  {activityData.remainingTickets?.byType[ticketType.name] ?? ticketType.quantity} tilgjengelige · {ticketType.memberTypes.map(getMemberTypeLabel).join(", ")}
                </small>
                {ticketSales && (activityData.status ?? "published") === "published" && (
                  <TicketPurchase
                    activity={activityData}
                    ticketType={ticketType}
                    member={ticketSales.member}
                  />
                )}
              </article>
            ))}
          </section>
        )}
        {ticketSales && (activityData.status ?? "published") === "published" &&
          !activityData.ticketTypes?.length && (
            <div className="activity-cart">
              {activityData.date < new Date().toISOString().slice(0, 10)
                ? <p>Aktiviteten er allerede avholdt.</p>
                : <>
                  <p>Pris og billettype er ikke oppgitt. Aktiviteten kan ikke bestilles før dette er lagt til.</p>
                  <button type="button" className="activity-cart-button" onClick={() => setAdded(add({ type: "activity", id: activityData.id, quantity: 1 }))}>Legg i handlekurv</button>
                  {added && <p role="status">Aktiviteten er lagt i handlekurven.</p>}
                  {error && <p role="alert">{error}</p>}
                </>}
            </div>
          )}
        {ticketSales?.isAdmin && <ActivityParticipants activityId={activityData.id} />}
      </section>
    </article>
  );
}
